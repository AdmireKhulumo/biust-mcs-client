import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
	MenuItem,
	FormControl,
	ListSubheader,
	Select,
	Typography,
	InputLabel,
	Grid
} from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
	formControl: {
		margin: theme.spacing(1),
		minWidth: " 200px"
	}
}));

export default function GroupedSelect() {
	const classes = useStyles();

	return (
		<div>
			<Grid
				container
				spacing={3}
				direction="row"
				justify="center"
				alignItems="center"
				style={{ paddingLeft: "20px", paddingRight: "20px" }}
			>
				<Grid item>
					<Typography variant="overline">Select Station and Date: </Typography>
				</Grid>

				<Grid item>
					<FormControl className={classes.formControl}>
						<InputLabel htmlFor="grouped-native-select">STATION</InputLabel>
						<Select native defaultValue="" id="grouped-native-select">
							<option aria-label="None" value="" />
							<optgroup label="Category 1">
								<option value={1}>New Main Gate</option>
								<option value={2}>Option 2</option>
							</optgroup>
							<optgroup label="Category 2">
								<option value={3}>O01/06/2020</option>
								<option value={4}>Option 4</option>
							</optgroup>
						</Select>
					</FormControl>
				</Grid>
				<Grid item>
					<FormControl className={classes.formControl}>
						<InputLabel htmlFor="grouped-native-select">DATE</InputLabel>
						<Select native defaultValue="" id="grouped-native-select">
							<option aria-label="None" value="" />
							<optgroup label="Category 1">
								<option value={1}>01/06/2020</option>
								<option value={2}>Option 2</option>
							</optgroup>
							<optgroup label="Category 2">
								<option value={3}>Option 3</option>
								<option value={4}>Option 4</option>
							</optgroup>
						</Select>
					</FormControl>
				</Grid>
			</Grid>
		</div>
	);
}
